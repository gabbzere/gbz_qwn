RunPod Qwen Image 2.1 Turbo startup template
============================================
Use a RunPod GPU Pod with a CUDA/PyTorch base image (NOT the official auto-starting ComfyUI template).
Mount persistent storage at /workspace, with at least 40 GB free (more recommended).
Expose port 8188 as HTTP.

1. Put start.sh and qwenImage21TurboGenerate_v12.json in /workspace on your persistent volume.
2. In RunPod template -> Container Start Command, set:
   bash /workspace/start.sh
3. Optionally configure environment variables:
   ARCHER2_URL=https://.../ARCHER2.safetensors
   LENOVO_QWEN21_URL=https://.../lenovo_qwen21.safetensors
   HF_TOKEN=... (only if needed for gated/private Hugging Face downloads)
   PYTHON=python (override if the base image uses a dedicated virtual environment)
4. Start the Pod and wait for downloading/installing to complete; then open port 8188.

On every boot, downloaded files are detected and reused rather than re-downloaded.
Note: The workflow references WhitneyUpscaler.png; upload that reference image in ComfyUI. A workflow JSON does not contain the image bytes.
Note: If either personal LoRA is absent, the workflow's LoRA Loader may fail (on_missing=error). Both are required by the current saved workflow.
Note: This template is a boot script, not a tested RunPod deployment; exact Python/CUDA compatibility depends on your selected base image.
Note: The workflow has a ComfySwitchNode. If it is not registered by your ComfyUI build, update ComfyUI or install its missing node dependency through Manager.
Note: Do not expose ComfyUI publicly without considering authentication; RunPod HTTP proxy access may be unauthenticated.

For automatic first deployment from scratch, host start.sh at a stable HTTPS URL (e.g., GitHub repo),
then set your RunPod template Start Command to:
   bash -lc 'curl -fsSL https://raw.githubusercontent.com/YOUR_ACCOUNT/YOUR_REPO/main/start.sh -o /tmp/qwen21-start.sh && bash /tmp/qwen21-start.sh'
The workflow JSON can be placed persistently in /workspace. Replace the placeholder URL before deployment.

ADDED: COMFYUI LORA MANAGER
The startup script now installs willmiao/ComfyUI-Lora-Manager into
ComfyUI/custom_nodes and installs its requirements before launching ComfyUI.
After startup, open the RunPod HTTP proxy for port 8188 and append /loras
to the ComfyUI URL, or use the Launch LoRA Manager button in ComfyUI.
For CivitAI downloads, enter your CivitAI API key in LoRA Manager settings.
The manager loads existing LoRAs automatically, so it does not require
changing the original workflow's AusBoss LoRA Loader.
