#!/usr/bin/env bash
set -Eeuo pipefail

# RunPod GPU Pod startup script for qwenImage21TurboGenerate_v12.json
# Intended for a RunPod PyTorch CUDA image, not the auto-starting ComfyUI image.
# Store /workspace on persistent storage and put this script at /workspace/start.sh.

WORKSPACE="${WORKSPACE:-/workspace}"
COMFY_DIR="${COMFY_DIR:-$WORKSPACE/ComfyUI}"
PORT="${PORT:-8188}"
PYTHON="${PYTHON:-python}"
INSTALL_COMFY_DEPS="${INSTALL_COMFY_DEPS:-1}"
COMFY_REF="${COMFY_REF:-master}"
# Set these in RunPod environment variables for the two private/custom LoRAs.
ARCHER2_URL="${ARCHER2_URL:-}"
LENOVO_QWEN21_URL="${LENOVO_QWEN21_URL:-}"
HF_TOKEN="${HF_TOKEN:-}"

log() { printf '\n[%s] %s\n' "$(date -u +'%Y-%m-%d %H:%M:%S UTC')" "$*"; }
trap 'log "Setup failed at line $LINENO. Check the log above."' ERR
mkdir -p "$WORKSPACE"
if ! command -v git >/dev/null; then
  apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y git ca-certificates curl
fi

if [[ ! -f "$COMFY_DIR/main.py" ]]; then
  log "Cloning ComfyUI into $COMFY_DIR"
  git clone --depth 1 https://github.com/Comfy-Org/ComfyUI.git "$COMFY_DIR"
else
  log "Using existing ComfyUI at $COMFY_DIR (no destructive updates)"
fi
if [[ "$INSTALL_COMFY_DEPS" == "1" ]]; then
  log "Installing ComfyUI Python requirements (retaining existing CUDA PyTorch)"
  "$PYTHON" -m pip install -r "$COMFY_DIR/requirements.txt"
fi

CUSTOM="$COMFY_DIR/custom_nodes"
MODELS="$COMFY_DIR/models"
mkdir -p "$CUSTOM" "$MODELS/diffusion_models" "$MODELS/text_encoders" "$MODELS/vae" "$MODELS/loras/Qwen21" "$COMFY_DIR/user/default/workflows" "$COMFY_DIR/input"

if [[ ! -d "$CUSTOM/ComfyUI-AusBoss/.git" ]]; then
  log "Installing AusBoss nodes"
  git clone --depth 1 https://github.com/ausboss/ComfyUI-AusBoss.git "$CUSTOM/ComfyUI-AusBoss"
else
  log "AusBoss nodes already installed"
fi
if [[ -f "$CUSTOM/ComfyUI-AusBoss/requirements.txt" ]]; then
  "$PYTHON" -m pip install -r "$CUSTOM/ComfyUI-AusBoss/requirements.txt"
fi

# LoRA Manager: install alongside AusBoss before starting ComfyUI.
LORA_MANAGER_DIR="$CUSTOM/ComfyUI-Lora-Manager"
if [[ ! -d "$LORA_MANAGER_DIR/.git" ]]; then
  log "Installing ComfyUI LoRA Manager"
  git clone --depth 1 https://github.com/willmiao/ComfyUI-Lora-Manager.git "$LORA_MANAGER_DIR"
else
  log "ComfyUI LoRA Manager already installed"
fi
if [[ -f "$LORA_MANAGER_DIR/requirements.txt" ]]; then
  log "Installing LoRA Manager Python dependencies"
  "$PYTHON" -m pip install -r "$LORA_MANAGER_DIR/requirements.txt"
fi

# This workflow uses ComfyUI built-in Qwen2.1, TextGenerate, StringFormat,
# ComfySwitchNode, and QwenImage21Cache, so use a recent ComfyUI installation.
# Do not pin an old version of ComfyUI.

fetch() {
  local url="$1" dest="$2" tmp
  if [[ -s "$dest" ]]; then
    log "Already downloaded: $dest"
    return 0
  fi
  mkdir -p "$(dirname "$dest")"
  tmp="${dest}.partial"
  log "Downloading $(basename "$dest")"
  local args=(-fL --retry 8 --retry-delay 5 --connect-timeout 30 -C -)
  if [[ -n "$HF_TOKEN" && "$url" == *huggingface.co* ]]; then
    args+=(-H "Authorization: Bearer ${HF_TOKEN}")
  fi
  curl "${args[@]}" -o "$tmp" "$url"
  [[ -s "$tmp" ]] || { log "Empty download: $url"; return 1; }
  mv -f "$tmp" "$dest"
}

BASE='https://huggingface.co/Comfy-Org/Qwen-Image-2.1/resolve/main'
fetch "$BASE/diffusion_models/qwen_image_2.1_turbo_int8_convrot.safetensors" "$MODELS/diffusion_models/qwen_image_2.1_turbo_int8_convrot.safetensors"
fetch "$BASE/text_encoders/qwen3vl_8b_int8_convrot.safetensors" "$MODELS/text_encoders/qwen3vl_8b_int8_convrot.safetensors"
fetch "$BASE/vae/qwen_image_2.1_vae_bf16.safetensors" "$MODELS/vae/qwen_image_2.1_vae_bf16.safetensors"
fetch 'https://huggingface.co/ausboss/Qwen-Image-2.1-Consistency-LoRA/resolve/main/qwen-image-2.1-consistency.safetensors' "$MODELS/loras/qwen-image-2.1-consistency.safetensors"
fetch 'https://huggingface.co/ausboss/Qwen-Image-2.1-Restore-LoRA/resolve/main/qwen-image-2.1-restore.safetensors' "$MODELS/loras/qwen-image-2.1-restore.safetensors"

if [[ -n "$ARCHER2_URL" ]]; then
  fetch "$ARCHER2_URL" "$MODELS/loras/Qwen21/ARCHER2.safetensors"
else
  log 'ARCHER2_URL not set. Supply it or copy ARCHER2.safetensors to models/loras/Qwen21/'
fi
if [[ -n "$LENOVO_QWEN21_URL" ]]; then
  fetch "$LENOVO_QWEN21_URL" "$MODELS/loras/Qwen21/lenovo_qwen21.safetensors"
else
  log 'LENOVO_QWEN21_URL not set. Supply it or copy lenovo_qwen21.safetensors to models/loras/Qwen21/'
fi

# Optional workflow JSON: place it alongside this script on persistent storage.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKFLOW_SOURCE="$SCRIPT_DIR/qwenImage21TurboGenerate_v12.json"
if [[ -f "$WORKFLOW_SOURCE" ]]; then
  cp -f "$WORKFLOW_SOURCE" "$COMFY_DIR/user/default/workflows/qwenImage21TurboGenerate_v12.json"
  log "Copied workflow JSON into ComfyUI's user workflows"
fi

log 'Checking model file existence'
for model in \
 "$MODELS/diffusion_models/qwen_image_2.1_turbo_int8_convrot.safetensors" \
 "$MODELS/text_encoders/qwen3vl_8b_int8_convrot.safetensors" \
 "$MODELS/vae/qwen_image_2.1_vae_bf16.safetensors" \
 "$MODELS/loras/qwen-image-2.1-consistency.safetensors" \
 "$MODELS/loras/qwen-image-2.1-restore.safetensors"; do
  test -s "$model" || { log "Missing $model"; exit 1; }
done

log "Starting ComfyUI on 0.0.0.0:$PORT"
cd "$COMFY_DIR"
exec "$PYTHON" main.py --listen 0.0.0.0 --port "$PORT"
